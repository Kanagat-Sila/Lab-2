#Example1----------------------------------------------------
a = "Hello, World!"
print(a.upper())
#Example2----------------------------------------------------
a = "Hello, World!"
print(a.lower())
#Example3----------------------------------------------------
a = " Hello, World! "
print(a.strip()) # returns "Hello, World!"
#Example4----------------------------------------------------
a = "Hello, World!"
print(a.replace("H", "J"))
#Example5----------------------------------------------------
a = "Hello, World!"
print(a.split(",")) # returns ['Hello', ' World!']