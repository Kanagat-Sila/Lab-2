#Example1----------------------------------------------------
#This is a comment
print("Hello, World!")
#Example2----------------------------------------------------
print("Hello, World!") #This is a comment
#Example3----------------------------------------------------
#print("Hello, World!")
print("Cheers, Mate!")
#Example4----------------------------------------------------
#This is a comment
#written in
#more than just one line
print("Hello, World!")
#Example5----------------------------------------------------
"""
This is a comment
written in
more than just one line
"""
print("Hello, World!")
#Exercise1----------------------------------------------------
#This is a comment
#Exercise2----------------------------------------------------
"""
This is a comment
written in
more than just one line
"""