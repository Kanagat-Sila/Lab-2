#Exercise1----------------------------------------------------
x = "Hello World"
print(len(x))
#Exercise2----------------------------------------------------
txt = "Hello World"
x = txt[0]
#Exercise3----------------------------------------------------
txt = "Hello World"
x = txt[2:5]
#Exercise4----------------------------------------------------
txt = " Hello World "
x = txt.strip()
#Exercise5----------------------------------------------------
txt = "Hello World"
txt = txt.upper()
#Exercise6----------------------------------------------------
txt = "Hello World"
txt = txt.lower()
#Exercise7----------------------------------------------------
txt = "Hello World"
txt = txt.replace("H","J")
#Exercise8----------------------------------------------------
age = 36
txt = "My name is John, and I am {}"
print(txt.format(age))