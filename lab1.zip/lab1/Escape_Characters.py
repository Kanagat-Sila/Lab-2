#Example1----------------------------------------------------
txt = "We are the so-called \"Vikings\" from the north."
#Example2----------------------------------------------------
#\'	Single Quote	
#\\	Backslash	
#\n	New Line	
#\r	Carriage Return	
#\t	Tab	
#\b	Backspace	
#\f	Form Feed	
#\ooo	Octal value	
#\xhh	Hex value