#Example1----------------------------------------------------
if 5 > 2:
    print("Five is greater than two!")
#Example2----------------------------------------------------
if 5 > 2:
 print("Five is greater than two!") 
if 5 > 2:
        print("Five is greater than two!")  
#Example3----------------------------------------------------
x = 5
y = "Hello, World!"
#Example4----------------------------------------------------
#This is a comment.
print("Hello, World!")
#Exercise1----------------------------------------------------
print("Hello World!")
#Exercise2----------------------------------------------------
if 5 > 2:
    print("YES")