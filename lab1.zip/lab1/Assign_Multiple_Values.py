#Example1----------------------------------------------------
x, y, z = "Orange", "Banana", "Cherry"
print(x)
print(y)
print(z)
#Example2----------------------------------------------------
x = y = z = "Orange"
print(x)
print(y)
print(z)
#Example3----------------------------------------------------
fruits = ["apple", "banana", "cherry"]
x, y, z = fruits
print(x)
print(y)
print(z)
